#pragma once

typedef void *mbedtls_threading_mutex_t;
